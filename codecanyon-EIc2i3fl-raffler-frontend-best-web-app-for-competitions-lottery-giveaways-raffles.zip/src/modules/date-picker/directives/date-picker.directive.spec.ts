import { DatePickerDirective } from './date-picker.directive';

describe('DatePickerDirective', () => {
  it('should create an instance', () => {
    const directive = new DatePickerDirective();
    expect(directive).toBeTruthy();
  });
});
