import { SecurePasswordDirective } from './secure-password.directive';

describe('SecurePasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new SecurePasswordDirective();
    expect(directive).toBeTruthy();
  });
});
