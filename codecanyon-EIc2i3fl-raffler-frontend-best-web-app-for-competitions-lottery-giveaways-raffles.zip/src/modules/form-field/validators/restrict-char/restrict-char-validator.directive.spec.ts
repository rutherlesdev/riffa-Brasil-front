import { RestrictCharValidatorDirective } from './restrict-char-validator.directive';

describe('RestrictCharValidatorDirective', () => {
    it('should create an instance', () => {
        const directive = new RestrictCharValidatorDirective();
        expect(directive).toBeTruthy();
    });
});
