export class DialogConfig<D = any> {
    public data?: D;
}
