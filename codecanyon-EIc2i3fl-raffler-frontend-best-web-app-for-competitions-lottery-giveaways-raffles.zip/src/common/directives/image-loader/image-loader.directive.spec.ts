import { ImageLoaderDirective } from './image-loader.directive';

describe('ImageLoaderDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageLoaderDirective(null, null);
    expect(directive).toBeTruthy();
  });
});
