
export enum DrawEntryStatus {
  Open,
  NonUserSelected,
  UserSelected
}

// export interface IDay {
//   dayInMonth: number;
//   dayInWeek: number;
//   date: Date;
//   status: DayStatus;
//   // events: CalendarEvent[];
// }
