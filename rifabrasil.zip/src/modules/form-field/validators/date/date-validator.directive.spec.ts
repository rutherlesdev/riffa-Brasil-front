import { DateValidatorDirective } from './date-validator.directive';

describe('DateValidatorDirective', () => {
    it('should create an instance', () => {
        const directive = new DateValidatorDirective(null);
        expect(directive).toBeTruthy();
    });
});
