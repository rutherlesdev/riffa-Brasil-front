import { DialogInsertionDirective } from './dialog-insertion.directive';

describe('DialogInsertionDirective', () => {
  it('should create an instance', () => {
    const directive = new DialogInsertionDirective(null);
    expect(directive).toBeTruthy();
  });
});
